a = input("Enter value: ")
print(a)

b = int(a)

print("Entered value is: " , str(b))

