a = 5
print("the value of a is " , a)