array = [1,2,3,4]

print(array[1])

array = [0]*10

print(array)